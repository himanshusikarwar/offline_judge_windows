# Windows Installation Guide

## ✅ What You DON'T Need to Install

The `.exe` file is **standalone** and includes everything needed to run the application:
- ✅ **Node.js** - Already bundled (no need to install)
- ✅ **Electron runtime** - Already bundled
- ✅ **All application files** - Already included

**You can simply:**
1. Double-click `DSA Practice Setup 1.0.0.exe`
2. Follow the installation wizard
3. Launch the app from Start Menu or Desktop shortcut

## ⚠️ What You MAY Need to Install (Optional)

The app can run code in different programming languages. To use these features, you need to install the corresponding runtime:

### 1. Java JDK (Required for Java Problems)

**Download:** https://adoptium.net/ (recommended) or https://www.oracle.com/java/

**Installation:**
- Download the Windows installer
- Run the installer
- Make sure "Add to PATH" is checked during installation
- Restart your computer after installation

**Verify Installation:**
- Open Command Prompt
- Type: `java -version`
- You should see Java version information

**Recommended Version:** Java 11 or higher

---

### 2. Python 3 (Required for Python Problems)

**Download:** https://www.python.org/downloads/

**Installation:**
- Download Python 3.8 or higher
- Run the installer
- ✅ **IMPORTANT:** Check "Add Python to PATH" during installation
- Click "Install Now"

**Verify Installation:**
- Open Command Prompt
- Type: `python --version` or `python3 --version`
- You should see Python version information

**Recommended Version:** Python 3.8 or higher

---

### 3. C++ Compiler (Optional - Only for C++ Problems)

**Option A: MinGW-w64 (Recommended)**
- Download: https://www.mingw-w64.org/downloads/
- Or use MSYS2: https://www.msys2.org/
- Install and add to PATH

**Option B: Microsoft Visual C++**
- Comes with Visual Studio
- Download Visual Studio Community (free): https://visualstudio.microsoft.com/

**Verify Installation:**
- Open Command Prompt
- Type: `g++ --version` (for MinGW) or `cl` (for MSVC)
- You should see compiler version information

---

## Quick Start

### Minimal Setup (App Only)
1. Install `DSA Practice Setup 1.0.0.exe`
2. Launch the app
3. ✅ The app will work, but you can only view problems (not run code)

### Full Setup (With Code Execution)
1. Install `DSA Practice Setup 1.0.0.exe`
2. Install **Java JDK** (if you want to solve Java problems)
3. Install **Python 3** (if you want to solve Python problems)
4. Install **C++ Compiler** (if you want to solve C++ problems)
5. Launch the app
6. ✅ You can now run and test code!

## How the App Detects Runtimes

The app automatically detects installed runtimes:
- Checks system PATH
- Shows available languages in the UI
- Displays error messages if runtime is missing when trying to run code

## Troubleshooting

### "Java not found" Error
- Install Java JDK from https://adoptium.net/
- Make sure Java is added to PATH
- Restart your computer
- Verify with: `java -version` in Command Prompt

### "Python not found" Error
- Install Python from https://www.python.org/downloads/
- ✅ **Check "Add Python to PATH" during installation**
- Restart your computer
- Verify with: `python --version` in Command Prompt

### "C++ compiler not found" Error
- Install MinGW-w64 or Visual Studio
- Add compiler to PATH
- Restart your computer
- Verify with: `g++ --version` in Command Prompt

### App Won't Start
- Make sure you ran the installer (don't just extract files)
- Check Windows Defender/Antivirus isn't blocking it
- Try running as Administrator
- Check Windows Event Viewer for errors

### Code Execution Fails
- Verify the runtime is installed: `java -version`, `python --version`
- Make sure the runtime is in PATH
- Restart the app after installing runtimes
- Check that Windows Firewall isn't blocking the app

## System Requirements

- **OS:** Windows 10 or higher (64-bit)
- **RAM:** 4GB minimum, 8GB recommended
- **Disk Space:** ~200MB for app + additional space for runtimes
- **Internet:** Not required (fully offline after installation)

## Summary

| Component | Required? | Included in .exe? |
|-----------|-----------|-------------------|
| Application | ✅ Yes | ✅ Yes |
| Node.js | ❌ No | ✅ Yes (bundled) |
| Electron | ❌ No | ✅ Yes (bundled) |
| Java JDK | ⚠️ Optional | ❌ No (user installs) |
| Python 3 | ⚠️ Optional | ❌ No (user installs) |
| C++ Compiler | ⚠️ Optional | ❌ No (user installs) |

**Bottom Line:** Install the .exe, and optionally install Java/Python/C++ if you want to run code in those languages!

